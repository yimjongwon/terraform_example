exports.handler = async (event) => {
    const response = {
        statusCode: 200,
        body: JSON.stringify('Hello from Node.js 18 Lambda! [SUCCESS]'),
    };
    return response;
};
